# Spark-Virtual-Assistant
Fourth semester project for Chandigarh University.Team leader of this project is Pratyush Saraswat .Team members are Anmol kaur,Rijul shakya, Shivam prasad Gupta and Kushal pratap singh. 
